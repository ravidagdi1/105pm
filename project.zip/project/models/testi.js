const mongoose=require('mongoose')


const testSchema=mongoose.Schema({
    img:String,
    testi:String,
    cname:String,
    status:{type:String,default:'unpublish'}
})

module.exports=mongoose.model('testi',testSchema)