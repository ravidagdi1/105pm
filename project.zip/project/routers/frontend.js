const router=require('express').Router()//module
const cbanner=require('../controllers/bannercontroller')
const creg=require('../controllers/regcontroller')
const Banner=require('../models/banner')
const Query=require('../models/query')
const Services=require('../models/service')
const Testi=require('../models/testi')
const multer=require('multer')
const Reg= require("../models/reg")
let sess=null

function handlelogin(req,res,next){
   if(req.session.isAuth){
      next()
   }else{
      res.redirect('/login')
   }
}

function hanlderole(req,res,next){
   if(sess.role=='pvt'){
      next()
   }else{
     res.send("You dont have rights to see this page") 
   }
}

   let storage=multer.diskStorage({
   destination:function(req,file,cb){
       cb(null,'./public/upload')
   },
   filename:function(req,file,cb){
       cb(null,  Date.now()+file.originalname)
   }
})

let upload=multer({
   storage:storage,
   limits:{fileSize:1024*1024*4}
})


router.get('/',handlelogin,async(req,res)=>{
   const record= await Banner.findOne() 
    const servicesdata=  await Services.find({status:'publish'})
    const testidata=  await Testi.find({status:'publish'})
    //console.log(sess.username)
    if(sess!==null){
    res.render('index.ejs',{record,servicesdata,testidata,username:sess.username})
    }else{
      res.render('index.ejs',{record,servicesdata,testidata,username:'hello'})

    }
})
router.get('/banner',handlelogin,cbanner.bannerShow)

router.post('/queryrecord',async(req,res)=>{
   const{email,query}=req.body
  const record= new Query({ email:email,query:query,status:'unread'})
 await record.save()
 res.redirect('/')
 //console.log(record)

})

router.get('/testi',handlelogin,hanlderole,(req,res)=>{
   if(sess!==null){
   res.render('testi.ejs',{username:sess.username})
   }else{
      res.render('testi.ejs',{username:'hello'})
 
   }
})

router.post('/testirecords',upload.single('img'),async(req,res)=>{
   const imagename=req.file.filename
   const{qt,canme}=req.body
  const record= new Testi({img:imagename,testi:qt,cname:canme})
   await record.save()
   res.redirect('/')
   //console.log(record)
})

router.get('/servicedetail/:id',handlelogin,async(req,res)=>{
   const id=req.params.id
   const record=await Services.findById(id)
   res.render('servicedetail.ejs',{record})
})
router.get('/reg',creg.regshow)
router.post('/regrecords',creg.reginsert)

router.get('/login',(req,res)=>{
   if(sess!==null){
   res.render('login.ejs',{message:'',username:sess.username})
   }else{
      res.render('login.ejs',{message:'',username:'hello'})
 
   }
})
router.post('/loginrecords',async(req,res)=>{
   const{us,pass}=req.body
  const record= await Reg.findOne({username:us})
  if(record!==null){
   if(record.password==pass){
      if(record.status=='active'){
   req.session.isAuth=true
   sess=req.session
   sess.username=us
   sess.role=record.role
   res.redirect('/')
      }else{
         res.send("you account is suspended.Plz cordinate with your Admin")
      }
   }else{
      if(sess!==null){
         res.render('login.ejs',{message:'Wrong credentails',username:sess.username})
         }else{
            res.render('login.ejs',{message:'Wrong credentails',username:'hello'})
       
         }
   }
  }else{
   if(sess!==null){
      res.render('login.ejs',{message:'Wrong credentails',username:sess.username})
      }else{
         res.render('login.ejs',{message:'Wrong Credentails',username:'hello'})
    
      }
  }

})

router.get('/logout',(req,res)=>{
   req.session.destroy()
   sess=null
   res.redirect('/login')
})

router.get('/profile',handlelogin,async(req,res)=>{
   if(sess!==null){
const record=await Reg.findOne({username:sess.username})
   res.render("profile.ejs",{message:'',record,username:sess.username})
   }else{
      res.render("profile.ejs",{username:'hello'})
 
   }
})

router.post('/profile/:id',upload.single('img'),async(req,res)=>{
   const id= req.params.id
   const{fname,lname,email}=req.body
   if(req.file){
   const imgfilename=req.file.filename
   await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,email:email,img:imgfilename})
   
   }else{
      await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,email:email})

   }
   if(sess!==null){
      const record=await Reg.findOne({username:sess.username})
         res.render("profile.ejs",{message:'Profile has been updated',record,username:sess.username})
         }else{
            res.render("profile.ejs",{message:'Profile has been updated',username:'hello'})
       
         }
})

router.get('/password',handlelogin,(req,res)=>{
   if(sess!==null){
   res.render('password.ejs',{username:sess.username})
   }
})

router.post('/password',handlelogin,async(req,res)=>{
   const{cpass,npass}=req.body
  const record= await Reg.findOne({username:sess.username})
  if(record.password==cpass){
   const id=record.id
   await Reg.findByIdAndUpdate(id,{password:npass})
   res.redirect('/password')
  }else{
   res.send("current password not matched")
  }
})






module.exports=router