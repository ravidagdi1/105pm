const Reg=require('../models/reg')


let sess=null;

exports.regshow=(req,res)=>{
    if(sess!==null){
    res.render('reg.ejs',{username:sess.username})
    }else{
       res.render('reg.ejs',{username:'hello'})
 
    }
 }

 exports.reginsert=async(req,res)=>{
    const{us,pass}=req.body
    const checkuser=await Reg.findOne({username:us})
    if(checkuser==null){
   const record= new Reg({username:us,password:pass})
   await record.save()
    }else{
       res.send("Your name Already exist")
    }
   //console.log(record)

 }

 exports.regshowadmin=async(req,res)=>{
    const record=await Reg.find().sort({createdDate:-1})
    res.render('admin/reg.ejs',{record})
}

exports.regupdateadmin=async(req,res)=>{
    const id=req.params.id
   const record= await Reg.findById(id)
   let newstatus=null
   if(record.status=='active'){
    newstatus='suspended'
   }else{
    newstatus='active'
   }
   await Reg.findByIdAndUpdate(id,{status:newstatus})
   res.redirect('/admin/reg')
}
