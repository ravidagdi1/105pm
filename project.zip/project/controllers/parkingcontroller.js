const Parking=require('../models/parking')


exports.parkingshow=async(req,res)=>{
    const record= await Parking.find()
    res.render('admin/parking.ejs',{record})
}

exports.parkingform=(req,res)=>{
    res.render('admin/parkingform.ejs')
}

exports.parkinginsert=async(req,res)=>{
    const{vno,vtype}=req.body
   const record= new Parking({vno:vno,vtype:vtype})
  await record.save()
  //console.log(record)
  res.redirect('/admin/parking')

}

exports.parkingupdateform=(req,res)=>{
    const id=req.params.id
    res.render('admin/parkingupdateform.ejs',{id})
}

exports.parkingupdate=async(req,res)=>{
const id=req.params.id
const vout=new Date()
const record=await Parking.findById(id)
const todatltime=(vout-record.vin)/(1000*60*60)
console.log(todatltime)
let amount=0
if(record.vtype=='2w'){
    amount=Math.round(todatltime*30)
}else if(record.vtype=='3w'){
    amount=Math.round(todatltime*50)

}
else if(record.vtype=='4w'){
    amount=Math.round(todatltime*80)

}
else if(record.vtype=='hw'){
    amount=Math.round(todatltime*120)

}
else if(record.vtype=='lw'){
    amount=Math.round(todatltime*100)

}

await Parking.findByIdAndUpdate(id,{vout:new Date(),amount:amount,status:'OUT'})
res.redirect('/admin/parking')

}

exports.parkingprint=async(req,res)=>{
    const id=req.params.id
    const record= await Parking.findById(id)
    res.render('admin/print.ejs',{record})

}


