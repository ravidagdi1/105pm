const Banner=require('../models/banner')


   exports.bannerShow=async(req,res)=>{
    const record= await Banner.findOne()
     res.render('banner.ejs',{record})
   }

   exports.bannershowadmin=async(req,res)=>{
    const record= await Banner.findOne()
     res.render('admin/banner.ejs',{record})
 }

 exports.bannerupdateform=async(req,res)=>{
    const id= req.params.abc
    const record= await Banner.findById(id)
    res.render('admin/bannerform.ejs',{record})
 }

 exports.bannerupdateadmin=async(req,res)=>{
   
    const id=req.params.abc
   const{title,desc,ldesc}=req.body
   if(req.file){
     const imgname=req.file.filename
 await Banner.findByIdAndUpdate(id,{title:title,desc:desc,ldesc:ldesc,img:imgname})
   }else{
     await Banner.findByIdAndUpdate(id,{title:title,desc:desc,ldesc:ldesc})
 
   }
 res.redirect('/admin/banner')
 }


 